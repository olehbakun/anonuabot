from aiogram import Bot, Dispatcher, F
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.enums import ParseMode
import asyncio
import logging
import sqlite3
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

# Проста база даних
conn = sqlite3.connect("db.sqlite3")
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, status TEXT)")
cursor.execute("CREATE TABLE IF NOT EXISTS queue (user_id INTEGER)")
conn.commit()

@dp.message(Command("start"))
async def start_cmd(message: Message):
    user_id = message.from_user.id
    cursor.execute("INSERT OR IGNORE INTO users (id, status) VALUES (?, ?)", (user_id, "idle"))
    conn.commit()
    await message.answer("👋 Привіт! Натисни кнопку 'Пошук', щоб знайти співрозмовника.")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(dp.start_polling(bot))