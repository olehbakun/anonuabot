# AnonChatUaBot

🇺🇦 Український Telegram бот для анонімного спілкування 1-на-1

## Запуск на Railway:
1. Завантаж ZIP на GitHub або Railway
2. Створи змінну середовища `BOT_TOKEN`
3. Натисни Deploy — і бот працює 24/7!